#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
# shellcheck disable=SC1091
source "${SCRIPT_DIR}/lib/common.sh"

SCRIPT_NAME="restore-configs.sh"
PRIMARY_USER="lukasz"
PRIMARY_USER_UID="1000"
PRIMARY_USER_SHELL="/usr/bin/zsh"
PRIMARY_USER_HOME="/home/${PRIMARY_USER}"
APPLY_NETWORK=false
ACTIVATE_OVERLAY=false
SELECTED_CATEGORIES=()
ALL_SAFE=false
ALL_PUBLIC=false
ALL_WITH_SECRETS=false

CATEGORIES=(
  apt-sources system-basics users usershell ssh boot-storage kernel
  network-base wireguard dns firewall nginx mariadb postfix prosody
  agate pygopherd mumble docker monitoring privacy tls identities
)

usage() {
  cat <<USAGE
Usage: sudo ./restore-configs.sh [options]

Purpose:
  Restore selected sanctum/labunix configs from capture-full.sh database.
  Safe by default: non-fatal, backup before overwrite, no blind identity restore.

Options:
  --db-dir PATH
  --role lab|hardware|replacement
  --category NAME             Repeatable; use --list-categories to inspect.
  --all-safe                  Safe subset; avoids identities and risky network takeover.
  --all-public                Restore every public category only.
  --all-with-secrets          Restore all categories and allow secret-backed items.
  --restore-secrets           Allow secret-backed service configs (.env, grafana.ini, etc.)
  --restore-identities        Allow host identities (SSH host keys, user SSH private keys,
                              GPG keyrings, Tor/I2P/TLS identities when category requests them)
  --network-mode safe|source  safe=do not replace base network wholesale; source=restore source trees
  --dns-mode auto|resolved|dnsmasq|unbound|chain
  --start-services            Validate and restart services after restore where reasonable
  --apply-network             Permit service restart of networking-related units when safe
  --activate-overlay          Permit wg-quick enable/start after WireGuard restore
  --primary-user NAME         Default: lukasz
  --primary-uid UID           Default: 1000
  --yes                       Non-interactive yes to prompts
  --dry-run
  --verbose
  --list-categories
  --help
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --db-dir) DB_DIR="$2"; PUBLIC_DIR="${DB_DIR}/db/public"; SECRET_DIR="${DB_DIR}/db/secret"; shift ;;
    --role) ROLE="$2"; shift ;;
    --category) SELECTED_CATEGORIES+=("$2"); shift ;;
    --all-safe) ALL_SAFE=true ;;
    --all-public) ALL_PUBLIC=true ;;
    --all-with-secrets) ALL_WITH_SECRETS=true; RESTORE_SECRETS=true ;;
    --restore-secrets) RESTORE_SECRETS=true ;;
    --restore-identities) RESTORE_IDENTITIES=true ;;
    --network-mode) NETWORK_MODE="$2"; shift ;;
    --dns-mode) DNS_MODE="$2"; shift ;;
    --start-services) START_SERVICES=true ;;
    --apply-network) APPLY_NETWORK=true ;;
    --activate-overlay) ACTIVATE_OVERLAY=true ;;
    --primary-user) PRIMARY_USER="$2"; PRIMARY_USER_HOME="/home/${PRIMARY_USER}"; shift ;;
    --primary-uid) PRIMARY_USER_UID="$2"; shift ;;
    --yes) ASSUME_YES=true ;;
    --dry-run) DRY_RUN=true ;;
    --verbose) VERBOSE=true ;;
    --list-categories) printf '%s\n' "${CATEGORIES[@]}"; exit 0 ;;
    --help) usage; exit 0 ;;
    *) die "unknown option: $1" ;;
  esac
  shift
done

ensure_root
load_optional_config
ensure_runtime_dirs
require_cmd rsync install getent systemctl awk sed grep

[[ -d ${PUBLIC_DIR} ]] || die "public DB missing: ${PUBLIC_DIR}"
[[ ${ROLE} =~ ^(lab|hardware|replacement)$ ]] || die "invalid role: ${ROLE}"
[[ ${NETWORK_MODE} =~ ^(safe|source)$ ]] || die "invalid network mode: ${NETWORK_MODE}"
[[ ${DNS_MODE} =~ ^(auto|resolved|dnsmasq|unbound|chain)$ ]] || die "invalid dns mode: ${DNS_MODE}"

SAFE_SET=(system-basics users usershell ssh nginx mariadb postfix prosody agate pygopherd mumble docker monitoring)
PUBLIC_SET=(apt-sources system-basics users usershell ssh boot-storage kernel network-base wireguard dns firewall nginx mariadb postfix prosody agate pygopherd mumble docker monitoring privacy tls)
FULL_SET=(apt-sources system-basics users usershell ssh boot-storage kernel network-base wireguard dns firewall nginx mariadb postfix prosody agate pygopherd mumble docker monitoring privacy tls identities)

if [[ ${ALL_SAFE} == true ]]; then
  SELECTED_CATEGORIES+=("${SAFE_SET[@]}")
fi
if [[ ${ALL_PUBLIC} == true ]]; then
  SELECTED_CATEGORIES+=("${PUBLIC_SET[@]}")
fi
if [[ ${ALL_WITH_SECRETS} == true ]]; then
  SELECTED_CATEGORIES+=("${FULL_SET[@]}")
fi
if [[ ${#SELECTED_CATEGORIES[@]} -eq 0 ]]; then
  die "no categories selected; use --category, --all-safe, --all-public or --all-with-secrets"
fi

unique_categories() {
  awk '!seen[$0]++'
}

mapfile -t SELECTED_CATEGORIES < <(printf '%s\n' "${SELECTED_CATEGORIES[@]}" | unique_categories)
for c in "${SELECTED_CATEGORIES[@]}"; do
  printf '%s\n' "${CATEGORIES[@]}" | grep -qx -- "${c}" || die "unknown category: ${c}"
done

log "${SCRIPT_NAME}: role=${ROLE} categories=${SELECTED_CATEGORIES[*]} db=${DB_DIR}"
report "${SCRIPT_NAME}" "run" "start" "init" "ok" "role=${ROLE}; categories=${SELECTED_CATEGORIES[*]}" ""

prompt_category() {
  local category="$1"
  prompt_yes_no "Restore category '${category}'?" yes
}

validate_and_maybe_start() {
  local category="$1" item="$2" validator="$3" unit="$4"
  if [[ -n ${validator} ]]; then
    if "${validator}"; then
      report "${SCRIPT_NAME}" "${category}" "${item}" "validate" "ok" "validation passed" ""
    else
      note_failure "${SCRIPT_NAME}" "${category}" "${item}" "validate" "validation failed"
      return 1
    fi
  fi

  if [[ ${START_SERVICES} == true && -n ${unit} ]]; then
    if systemctl_safe_enable "${unit}" && systemctl_safe_start "${unit}"; then
      report "${SCRIPT_NAME}" "${category}" "${item}" "start" "ok" "service restarted" ""
    else
      note_failure "${SCRIPT_NAME}" "${category}" "${item}" "start" "service enable/restart failed"
    fi
  else
    report "${SCRIPT_NAME}" "${category}" "${item}" "start" "skipped" "service start not requested" ""
  fi
  return 0
}

restore_public_dir() {
  local category="$1" item="$2" src_rel="$3" dst="$4" mode="${5:-}" owner="${6:-}" group="${7:-}"
  restore_path "${SCRIPT_NAME}" "${category}" "${item}" "${PUBLIC_DIR}/${src_rel}" "${dst}" "${mode}" "${owner}" "${group}"
}

restore_secret_dir() {
  local category="$1" item="$2" src_rel="$3" dst="$4" mode="${5:-}" owner="${6:-}" group="${7:-}"
  if [[ ${RESTORE_SECRETS} != true && ${RESTORE_IDENTITIES} != true ]]; then
    report "${SCRIPT_NAME}" "${category}" "${item}" "restore" "skipped" "secret restore not enabled" ""
    return 0
  fi
  restore_path "${SCRIPT_NAME}" "${category}" "${item}" "${SECRET_DIR}/${src_rel}" "${dst}" "${mode}" "${owner}" "${group}"
}

maybe_restore_public() {
  local category="$1" item="$2" src_rel="$3" dst="$4" mode="${5:-}" owner="${6:-}" group="${7:-}"
  if prompt_yes_no "  Restore ${category}/${item} -> ${dst}?" yes; then
    restore_public_dir "${category}" "${item}" "${src_rel}" "${dst}" "${mode}" "${owner}" "${group}"
  else
    report "${SCRIPT_NAME}" "${category}" "${item}" "restore" "skipped" "operator skipped" ""
  fi
}

maybe_restore_secret() {
  local category="$1" item="$2" src_rel="$3" dst="$4" mode="${5:-}" owner="${6:-}" group="${7:-}"
  if [[ ${RESTORE_SECRETS} != true && ${RESTORE_IDENTITIES} != true ]]; then
    report "${SCRIPT_NAME}" "${category}" "${item}" "restore" "skipped" "secret restore not enabled" ""
    return 0
  fi
  if prompt_yes_no "  Restore SECRET ${category}/${item} -> ${dst}?" no; then
    restore_secret_dir "${category}" "${item}" "${src_rel}" "${dst}" "${mode}" "${owner}" "${group}"
  else
    report "${SCRIPT_NAME}" "${category}" "${item}" "restore" "skipped" "operator skipped secret" ""
  fi
}

ensure_primary_user() {
  if id "${PRIMARY_USER}" >/dev/null 2>&1; then
    report "${SCRIPT_NAME}" "users" "${PRIMARY_USER}" "ensure" "ok" "user already exists" ""
    return 0
  fi
  if [[ ${DRY_RUN} == true ]]; then
    printf '[dry] useradd --uid %s --create-home --home-dir %s --shell %s --groups sudo %s\n' \
      "${PRIMARY_USER_UID}" "${PRIMARY_USER_HOME}" "${PRIMARY_USER_SHELL}" "${PRIMARY_USER}"
  else
    useradd --uid "${PRIMARY_USER_UID}" --create-home --home-dir "${PRIMARY_USER_HOME}" \
      --shell "${PRIMARY_USER_SHELL}" --groups sudo "${PRIMARY_USER}"
  fi
  report "${SCRIPT_NAME}" "users" "${PRIMARY_USER}" "ensure" "changed" "user created" ""
}

restore_category_apt_sources() {
  maybe_restore_public apt-sources sources.list packages/apt/sources.list /etc/apt/sources.list
  maybe_restore_public apt-sources sources.list.d packages/apt/sources.list.d /etc/apt/sources.list.d
  maybe_restore_public apt-sources preferences packages/apt/preferences /etc/apt/preferences
  maybe_restore_public apt-sources preferences.d packages/apt/preferences.d /etc/apt/preferences.d
  maybe_restore_public apt-sources apt.conf.d packages/apt/apt.conf.d /etc/apt/apt.conf.d

  if prompt_yes_no "  Run apt-get update after apt source restore?" yes; then
    if [[ ${DRY_RUN} == true ]]; then
      printf '[dry] apt-get update\n'
    elif apt-get update; then
      report "${SCRIPT_NAME}" "apt-sources" "apt-update" "update" "ok" "apt metadata refreshed" ""
    else
      note_failure "${SCRIPT_NAME}" "apt-sources" "apt-update" "update" "apt-get update failed"
    fi
  fi
}

restore_category_system_basics() {
  maybe_restore_public system-basics etc-hostname system/etc-hostname /etc/hostname
  maybe_restore_public system-basics etc-hosts system/etc-hosts /etc/hosts
  maybe_restore_public system-basics environment system/etc-environment /etc/environment
  maybe_restore_public system-basics locale.gen system/locale.gen /etc/locale.gen
  maybe_restore_public system-basics timezone system/timezone /etc/timezone

  if [[ -f ${PUBLIC_DIR}/system/etc-hostname ]] && prompt_yes_no "  Apply captured hostname now?" yes; then
    local desired
    desired="$(head -n1 "${PUBLIC_DIR}/system/etc-hostname" 2>/dev/null || true)"
    if [[ -n ${desired} ]]; then
      if [[ ${DRY_RUN} == true ]]; then
        printf '[dry] hostnamectl set-hostname %s\n' "${desired}"
      else
        hostnamectl set-hostname "${desired}"
      fi
      report "${SCRIPT_NAME}" "system-basics" "hostnamectl" "set" "changed" "${desired}" ""
    fi
  fi
}

restore_category_users() {
  ensure_primary_user
  maybe_restore_public users sudoers users/sudoers /etc/sudoers 440 root root
  maybe_restore_public users sudoers.d users/sudoers.d /etc/sudoers.d
  maybe_restore_public users shells users/shells /etc/shells
  maybe_restore_public users login.defs users/login.defs /etc/login.defs

  if [[ -f ${SECRET_DIR}/ssh/user-${PRIMARY_USER}/authorized_keys ]]; then
    install -d -m 0700 -o "${PRIMARY_USER}" -g "${PRIMARY_USER}" "${PRIMARY_USER_HOME}/.ssh"
    maybe_restore_secret users authorized_keys "ssh/user-${PRIMARY_USER}/authorized_keys" "${PRIMARY_USER_HOME}/.ssh/authorized_keys" 600 "${PRIMARY_USER}" "${PRIMARY_USER}"
  else
    report "${SCRIPT_NAME}" "users" "authorized_keys" "restore" "skipped" "secret authorized_keys not present" ""
  fi
}

restore_category_usershell() {
  maybe_restore_public usershell profile environment/profile /etc/profile
  maybe_restore_public usershell profile.d environment/profile.d /etc/profile.d
  maybe_restore_public usershell zsh environment/zsh /etc/zsh
  maybe_restore_secret usershell user-shell "shell/${PRIMARY_USER}" "${PRIMARY_USER_HOME}" "" "${PRIMARY_USER}" "${PRIMARY_USER}"
  maybe_restore_secret usershell root-shell "shell/root" /root
}

restore_category_ssh() {
  ensure_primary_user
  maybe_restore_public ssh sshd_config users/sshd_config /etc/ssh/sshd_config 644 root root
  maybe_restore_public ssh sshd_config.d users/sshd_config.d /etc/ssh/sshd_config.d
  validate_and_maybe_start ssh sshd validate_sshd ssh || true

  if [[ ${RESTORE_IDENTITIES} == true || ${ROLE} == replacement ]]; then
    maybe_restore_secret ssh host-keys ssh/etc-ssh /etc/ssh
  else
    report "${SCRIPT_NAME}" "ssh" "host-keys" "restore" "skipped" "identity restore not enabled" ""
  fi
  validate_and_maybe_start ssh sshd-after-keys validate_sshd ssh || true
}

restore_category_boot_storage() {
  maybe_restore_public boot-storage fstab system/etc-fstab /etc/fstab
  maybe_restore_public boot-storage crypttab system/etc-crypttab /etc/crypttab
  maybe_restore_public boot-storage zfs zfs/etc-zfs /etc/zfs
  maybe_restore_public boot-storage grub-default boot/grub-default /etc/default/grub
  maybe_restore_public boot-storage grub.d boot/grub.d /etc/grub.d
  maybe_restore_public boot-storage cryptsetup-initramfs boot/cryptsetup-initramfs /etc/cryptsetup-initramfs
  maybe_restore_public boot-storage initramfs-tools boot/initramfs-tools /etc/initramfs-tools
  maybe_restore_public boot-storage etc-kernel boot/etc-kernel /etc/kernel

  if prompt_yes_no "  Run update-initramfs and update-grub now?" no; then
    if [[ ${DRY_RUN} == true ]]; then
      printf '[dry] update-initramfs -u -k all\n[dry] update-grub\n'
    else
      update-initramfs -u -k all || note_failure "${SCRIPT_NAME}" boot-storage update-initramfs run "update-initramfs failed"
      update-grub || note_failure "${SCRIPT_NAME}" boot-storage update-grub run "update-grub failed"
    fi
    report "${SCRIPT_NAME}" "boot-storage" "boot-refresh" "run" "ok" "boot refresh requested" ""
  else
    report "${SCRIPT_NAME}" "boot-storage" "boot-refresh" "manual" "manual" "run update-initramfs/update-grub yourself when ready" ""
  fi
}

restore_category_kernel() {
  maybe_restore_public kernel sysctl.conf kernel/sysctl.conf /etc/sysctl.conf
  maybe_restore_public kernel sysctl.d kernel/sysctl.d /etc/sysctl.d
  maybe_restore_public kernel modules kernel/modules /etc/modules
  maybe_restore_public kernel modules-load.d kernel/modules-load.d /etc/modules-load.d
  maybe_restore_public kernel modprobe.d kernel/modprobe.d /etc/modprobe.d

  if prompt_yes_no "  Apply sysctl --system now?" yes; then
    if [[ ${DRY_RUN} == true ]]; then
      printf '[dry] sysctl --system\n'
    else
      sysctl --system >/dev/null || note_failure "${SCRIPT_NAME}" kernel sysctl apply "sysctl --system failed"
    fi
    report "${SCRIPT_NAME}" "kernel" "sysctl" "apply" "ok" "sysctl requested" ""
  fi
}

restore_category_network_base() {
  maybe_restore_public network-base hosts.allow network/hosts.allow /etc/hosts.allow
  maybe_restore_public network-base hosts.deny network/hosts.deny /etc/hosts.deny
  maybe_restore_public network-base nsswitch network/nsswitch.conf /etc/nsswitch.conf

  if [[ ${NETWORK_MODE} == source ]]; then
    maybe_restore_public network-base etc-network network/etc-network /etc/network
    maybe_restore_public network-base etc-netplan network/etc-netplan /etc/netplan
    maybe_restore_public network-base systemd-network network/systemd-network /etc/systemd/network
  else
    mark_manual "${SCRIPT_NAME}" network-base base-network-trees "NETWORK_MODE=safe; did not replace /etc/network, /etc/netplan, /etc/systemd/network"
  fi

  if [[ ${APPLY_NETWORK} == true ]]; then
    report "${SCRIPT_NAME}" "network-base" "apply-network" "manual" "manual" "deliberately not bouncing live networking automatically; review then restart manually" ""
  else
    report "${SCRIPT_NAME}" "network-base" "apply-network" "skipped" "network apply not requested" ""
  fi
}

restore_category_wireguard() {
  maybe_restore_public wireguard redacted-configs wireguard/etc-wireguard /etc/wireguard
  if [[ ${RESTORE_SECRETS} == true || ${RESTORE_IDENTITIES} == true || ${ROLE} == replacement ]]; then
    maybe_restore_secret wireguard real-configs wireguard/etc-wireguard /etc/wireguard
  else
    report "${SCRIPT_NAME}" "wireguard" "real-configs" "restore" "skipped" "real WG configs require --restore-secrets or replacement mode" ""
  fi

  if [[ ${ACTIVATE_OVERLAY} == true && ${START_SERVICES} == true && -d /etc/wireguard ]]; then
    local conf iface
    shopt -s nullglob
    for conf in /etc/wireguard/*.conf; do
      iface="$(basename "${conf}" .conf)"
      if prompt_yes_no "  Enable/start wg-quick@${iface}?" no; then
        systemctl_safe_enable "wg-quick@${iface}" || true
        systemctl_safe_start "wg-quick@${iface}" || note_failure "${SCRIPT_NAME}" wireguard "${iface}" start "wg-quick start failed"
      else
        report "${SCRIPT_NAME}" "wireguard" "${iface}" "start" "skipped" "operator skipped overlay activation" ""
      fi
    done
    shopt -u nullglob
  else
    report "${SCRIPT_NAME}" "wireguard" "activation" "start" "skipped" "overlay activation not requested" ""
  fi
}

choose_dns_mode() {
  local chosen
  if [[ ${DNS_MODE} != auto ]]; then
    printf '%s\n' "${DNS_MODE}"
    return 0
  fi
  if [[ -f ${PUBLIC_DIR}/dns/dnsmasq.conf && -d ${PUBLIC_DIR}/dns/etc-unbound ]]; then
    chosen="chain"
  elif [[ -d ${PUBLIC_DIR}/dns/etc-unbound ]]; then
    chosen="unbound"
  elif [[ -f ${PUBLIC_DIR}/dns/dnsmasq.conf ]]; then
    chosen="dnsmasq"
  else
    chosen="resolved"
  fi
  printf '%s\n' "${chosen}"
}

restore_category_dns() {
  local chosen
  chosen="$(choose_dns_mode)"
  report "${SCRIPT_NAME}" dns selected-mode decision ok "mode=${chosen}" ""

  case "${chosen}" in
    resolved)
      report "${SCRIPT_NAME}" dns resolved-config manual manual "systemd-resolved chosen; no db config restore needed" ""
      ;;
    dnsmasq)
      maybe_restore_public dns dnsmasq.conf dns/dnsmasq.conf /etc/dnsmasq.conf
      maybe_restore_public dns dnsmasq.d dns/dnsmasq.d /etc/dnsmasq.d
      validate_and_maybe_start dns dnsmasq validate_dnsmasq dnsmasq || true
      ;;
    unbound)
      maybe_restore_public dns etc-unbound dns/etc-unbound /etc/unbound
      validate_and_maybe_start dns unbound validate_unbound unbound || true
      ;;
    chain)
      maybe_restore_public dns dnsmasq.conf dns/dnsmasq.conf /etc/dnsmasq.conf
      maybe_restore_public dns dnsmasq.d dns/dnsmasq.d /etc/dnsmasq.d
      maybe_restore_public dns etc-unbound dns/etc-unbound /etc/unbound
      validate_and_maybe_start dns unbound validate_unbound unbound || true
      validate_and_maybe_start dns dnsmasq validate_dnsmasq dnsmasq || true
      ;;
  esac

  if [[ -f ${PUBLIC_DIR}/dns/resolv.conf ]] && prompt_yes_no "  Restore db/public/dns/resolv.conf to /etc/resolv.conf (NOT immutable)?" no; then
    restore_public_dir dns resolv.conf dns/resolv.conf /etc/resolv.conf
  else
    report "${SCRIPT_NAME}" dns resolv.conf restore skipped "did not replace /etc/resolv.conf" ""
  fi
}

restore_category_firewall() {
  maybe_restore_public firewall nftables.conf firewall/nftables.conf /etc/nftables.conf
  maybe_restore_public firewall nftables.d firewall/nftables.d /etc/nftables.d
  validate_and_maybe_start firewall nftables validate_nft nftables || true
}

restore_category_nginx() {
  maybe_restore_public nginx etc-nginx nginx/etc-nginx /etc/nginx
  maybe_restore_secret nginx htpasswd nginx /etc/nginx
  validate_and_maybe_start nginx nginx validate_nginx nginx || true
}

restore_category_mariadb() {
  maybe_restore_public mariadb etc-mysql mariadb/etc-mysql /etc/mysql
  maybe_restore_secret mariadb debian.cnf mariadb/debian.cnf /etc/mysql/debian.cnf 600 root root
  validate_and_maybe_start mariadb mariadb validate_mariadb mariadb || true
  if [[ ${RESTORE_SECRETS} == true && -d ${SECRET_DIR}/mariadb && ${START_SERVICES} == true ]] && prompt_yes_no "  Restore MariaDB schema-only dumps now (requires mariadb running)?" no; then
    local schema db
    shopt -s nullglob
    for schema in "${SECRET_DIR}"/mariadb/schema-*.sql; do
      db="$(basename "${schema}" .sql | sed 's/^schema-//')"
      if [[ ${DRY_RUN} == true ]]; then
        printf '[dry] mariadb -e CREATE DATABASE IF NOT EXISTS `%s`; mariadb %s < %s\n' "${db}" "${db}" "${schema}"
      else
        mariadb -e "CREATE DATABASE IF NOT EXISTS \\`${db}\\`;" >/dev/null 2>&1 || true
        if mariadb "${db}" < "${schema}"; then
          report "${SCRIPT_NAME}" mariadb "schema-${db}" restore ok "schema applied" ""
        else
          note_failure "${SCRIPT_NAME}" mariadb "schema-${db}" restore "schema apply failed"
        fi
      fi
    done
    shopt -u nullglob
  fi
}

restore_category_postfix() {
  maybe_restore_public postfix main.cf postfix/main.cf /etc/postfix/main.cf
  maybe_restore_public postfix master.cf postfix/master.cf /etc/postfix/master.cf
  maybe_restore_secret postfix sasl_passwd postfix/sasl_passwd /etc/postfix/sasl_passwd 600 root root
  if [[ -f /etc/postfix/sasl_passwd && ${DRY_RUN} == false ]]; then
    postmap /etc/postfix/sasl_passwd || note_failure "${SCRIPT_NAME}" postfix postmap run "postmap failed"
  fi
  validate_and_maybe_start postfix postfix validate_postfix postfix || true
}

restore_category_prosody() {
  if [[ ${RESTORE_SECRETS} == true && -d ${SECRET_DIR}/prosody/etc-prosody ]]; then
    maybe_restore_secret prosody etc-prosody prosody/etc-prosody /etc/prosody
  else
    maybe_restore_public prosody etc-prosody prosody/etc-prosody /etc/prosody
  fi
  validate_and_maybe_start prosody prosody "true" prosody || true
}

restore_category_agate() {
  maybe_restore_public agate agate.service agate/agate.service /etc/systemd/system/agate.service
  if [[ -f ${PUBLIC_DIR}/agate/capsule-structure.txt ]]; then
    install -d -m 0755 /srv/gemini-capsule
    report "${SCRIPT_NAME}" agate capsule create ok "/srv/gemini-capsule created; content restore is manual" ""
  fi
  run systemctl daemon-reload
  validate_and_maybe_start agate agate-service "true" agate || true
}

restore_category_pygopherd() {
  maybe_restore_public pygopherd etc-pygopherd pygopherd/etc-pygopherd /etc/pygopherd
  validate_and_maybe_start pygopherd pygopherd "true" pygopherd || true
}

restore_category_mumble() {
  maybe_restore_public mumble etc-mumble mumble/etc-mumble /etc/mumble
  validate_and_maybe_start mumble mumble "true" mumble-server || true
}

decode_compose_rel_to_path() {
  local rel="$1"
  printf '/%s\n' "${rel//__/\/}"
}

restore_compose_tree() {
  local base_dir="$1" source_kind="$2" rel src dst stack_dir
  [[ -d ${base_dir} ]] || return 0
  while IFS= read -r -d '' src; do
    rel="${src#${base_dir}/}"
    dst="$(decode_compose_rel_to_path "${rel}")"
    restore_path "${SCRIPT_NAME}" docker "${source_kind}:${rel}" "${src}" "${dst}"
    stack_dir="$(dirname "${dst}")"
    install -d -m 0755 "${stack_dir}"
  done < <(find "${base_dir}" -type f -print0 | sort -z)
}

start_compose_stacks() {
  local compose_file
  while IFS= read -r -d '' compose_file; do
    if prompt_yes_no "  Start stack $(dirname "${compose_file}")?" no; then
      if [[ ${DRY_RUN} == true ]]; then
        printf '[dry] (cd %s && docker compose pull && docker compose up -d)\n' "$(dirname "${compose_file}")"
      else
        ( cd "$(dirname "${compose_file}")" && docker compose pull && docker compose up -d ) \
          && report "${SCRIPT_NAME}" docker "$(dirname "${compose_file}")" start ok "docker compose up -d" "" \
          || note_failure "${SCRIPT_NAME}" docker "$(dirname "${compose_file}")" start "docker compose failed"
      fi
    else
      report "${SCRIPT_NAME}" docker "$(dirname "${compose_file}")" start skipped "operator skipped stack start" ""
    fi
  done < <(find /srv /opt /home /root -maxdepth 4 \( -name 'docker-compose.yml' -o -name 'docker-compose.yaml' -o -name 'compose.yml' -o -name 'compose.yaml' \) -print0 2>/dev/null)
}

restore_category_docker() {
  maybe_restore_public docker daemon.json docker/daemon.json /etc/docker/daemon.json
  if [[ -d ${PUBLIC_DIR}/docker/compose-redacted ]]; then
    if prompt_yes_no "  Restore redacted compose files from db/public?" yes; then
      restore_compose_tree "${PUBLIC_DIR}/docker/compose-redacted" public
    else
      report "${SCRIPT_NAME}" docker redacted-compose restore skipped "operator skipped redacted compose files" ""
    fi
  fi
  if [[ ${RESTORE_SECRETS} == true && -d ${SECRET_DIR}/docker/compose-full ]]; then
    if prompt_yes_no "  Restore full compose/.env files from secret DB?" no; then
      restore_compose_tree "${SECRET_DIR}/docker/compose-full" secret
    else
      report "${SCRIPT_NAME}" docker full-compose restore skipped "operator skipped full compose restore" ""
    fi
  fi

  if [[ ${START_SERVICES} == true ]]; then
    systemctl_safe_enable docker || true
    systemctl_safe_start docker || true
    report "${SCRIPT_NAME}" docker daemon start ok "docker service processed" ""
    if [[ ${RESTORE_SECRETS} == true ]] && prompt_yes_no "  Start restored Docker compose stacks now?" no; then
      start_compose_stacks
    fi
  else
    report "${SCRIPT_NAME}" docker daemon start skipped "service start not requested" ""
  fi
}

restore_category_monitoring() {
  maybe_restore_public monitoring prometheus prometheus/etc-prometheus /etc/prometheus
  maybe_restore_public monitoring node-exporter-defaults prometheus/node-exporter-defaults /etc/default/prometheus-node-exporter
  maybe_restore_public monitoring loki loki/etc-loki /etc/loki
  maybe_restore_public monitoring grafana grafana/etc-grafana /etc/grafana
  if [[ ${RESTORE_SECRETS} == true ]]; then
    maybe_restore_secret monitoring grafana.ini grafana/grafana.ini /etc/grafana/grafana.ini 640 root grafana
    maybe_restore_secret monitoring alloy-secret alloy/etc-alloy /etc/alloy
  else
    maybe_restore_public monitoring alloy-public alloy/etc-alloy /etc/alloy
  fi
  maybe_restore_public monitoring alloy-defaults alloy/etc-default-alloy /etc/default/alloy
  maybe_restore_public monitoring fail2ban fail2ban/etc-fail2ban /etc/fail2ban

  validate_and_maybe_start monitoring prometheus "true" prometheus || true
  validate_and_maybe_start monitoring node-exporter "true" prometheus-node-exporter || true
  validate_and_maybe_start monitoring loki "true" loki || true
  validate_and_maybe_start monitoring grafana "true" grafana-server || true
  validate_and_maybe_start monitoring alloy "true" alloy || true
  validate_and_maybe_start monitoring fail2ban "true" fail2ban || true
}

restore_category_privacy() {
  maybe_restore_public privacy torrc tor/torrc /etc/tor/torrc
  maybe_restore_public privacy torrc.d tor/torrc.d /etc/tor/torrc.d
  maybe_restore_public privacy i2pd i2pd/etc-i2pd /etc/i2pd

  if [[ ${RESTORE_IDENTITIES} == true || ${ROLE} == replacement ]]; then
    maybe_restore_secret privacy tor-data tor/var-lib-tor /var/lib/tor
    maybe_restore_secret privacy i2pd-data i2pd/var-lib-i2pd /var/lib/i2pd
  else
    report "${SCRIPT_NAME}" privacy tor-data restore skipped "identity restore not enabled" ""
    report "${SCRIPT_NAME}" privacy i2pd-data restore skipped "identity restore not enabled" ""
  fi

  validate_and_maybe_start privacy tor "true" tor || true
  validate_and_maybe_start privacy i2pd "true" i2pd || true
}

restore_category_tls() {
  maybe_restore_public tls renewal-configs tls/renewal-configs /etc/letsencrypt/renewal
  maybe_restore_public tls cli.ini tls/cli.ini /etc/letsencrypt/cli.ini
  if [[ ${RESTORE_IDENTITIES} == true || ${ROLE} == replacement ]]; then
    maybe_restore_secret tls letsencrypt tls/letsencrypt /etc/letsencrypt
  else
    report "${SCRIPT_NAME}" tls letsencrypt restore skipped "TLS private key restore requires --restore-identities or replacement role" ""
  fi
  if [[ ${START_SERVICES} == true ]]; then
    systemctl_safe_enable certbot.timer || true
    systemctl_safe_start nginx || true
    report "${SCRIPT_NAME}" tls certbot-timer start ok "certbot timer/nginx processed" ""
  fi
}

restore_category_identities() {
  if [[ ${RESTORE_IDENTITIES} != true && ${ROLE} != replacement ]]; then
    report "${SCRIPT_NAME}" identities all restore skipped "identities require --restore-identities or replacement role" ""
    return 0
  fi
  maybe_restore_secret identities ssh-host-keys ssh/etc-ssh /etc/ssh
  maybe_restore_secret identities user-ssh "ssh/user-${PRIMARY_USER}" "${PRIMARY_USER_HOME}/.ssh" "" "${PRIMARY_USER}" "${PRIMARY_USER}"
  if [[ -d ${SECRET_DIR}/gpg ]] && prompt_yes_no "  Import GPG key material for ${PRIMARY_USER}?" no; then
    local secfile trustfile
    secfile="${SECRET_DIR}/gpg/${PRIMARY_USER}-secret-keys.asc"
    trustfile="${SECRET_DIR}/gpg/${PRIMARY_USER}-ownertrust.txt"
    if [[ ${DRY_RUN} == true ]]; then
      printf '[dry] sudo -u %s gpg --import %s\n' "${PRIMARY_USER}" "${secfile}"
      printf '[dry] sudo -u %s gpg --import-ownertrust %s\n' "${PRIMARY_USER}" "${trustfile}"
    else
      [[ -f ${secfile} ]] && sudo -u "${PRIMARY_USER}" gpg --import "${secfile}" >/dev/null 2>&1 || true
      [[ -f ${trustfile} ]] && sudo -u "${PRIMARY_USER}" gpg --import-ownertrust "${trustfile}" >/dev/null 2>&1 || true
    fi
    report "${SCRIPT_NAME}" identities gpg import ok "gpg import attempted for ${PRIMARY_USER}" ""
  else
    report "${SCRIPT_NAME}" identities gpg import skipped "operator skipped GPG import" ""
  fi
}

run_category() {
  local category="$1"
  if ! prompt_category "${category}"; then
    report "${SCRIPT_NAME}" "${category}" "category" "restore" "skipped" "operator skipped category" ""
    return 0
  fi

  case "${category}" in
    apt-sources)    restore_category_apt_sources ;;
    system-basics)  restore_category_system_basics ;;
    users)          restore_category_users ;;
    usershell)      restore_category_usershell ;;
    ssh)            restore_category_ssh ;;
    boot-storage)   restore_category_boot_storage ;;
    kernel)         restore_category_kernel ;;
    network-base)   restore_category_network_base ;;
    wireguard)      restore_category_wireguard ;;
    dns)            restore_category_dns ;;
    firewall)       restore_category_firewall ;;
    nginx)          restore_category_nginx ;;
    mariadb)        restore_category_mariadb ;;
    postfix)        restore_category_postfix ;;
    prosody)        restore_category_prosody ;;
    agate)          restore_category_agate ;;
    pygopherd)      restore_category_pygopherd ;;
    mumble)         restore_category_mumble ;;
    docker)         restore_category_docker ;;
    monitoring)     restore_category_monitoring ;;
    privacy)        restore_category_privacy ;;
    tls)            restore_category_tls ;;
    identities)     restore_category_identities ;;
    *) die "category dispatch missing: ${category}" ;;
  esac
}

for category in "${SELECTED_CATEGORIES[@]}"; do
  log "processing category: ${category}"
  run_category "${category}"
done

set_state restore_configs done
report "${SCRIPT_NAME}" run finish exit ok completed ""
log "${SCRIPT_NAME}: done; report=${REPORT_FILE}"
